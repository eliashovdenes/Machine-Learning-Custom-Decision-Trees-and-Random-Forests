Run the notebook `run_experiments.ipynb` to reproduce the results in my report.

Python libraries used: NumPy, sklearn and matplotlib

The decision tree class is implemented in `decision_tree.py` and the random forest class is implemented in `random_forest.py`.